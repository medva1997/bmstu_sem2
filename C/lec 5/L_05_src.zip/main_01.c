/*
����� 4
*/

float avg(float a, float b)
{
    float c;

    c = a + b;

    return c / 2.0;
}
