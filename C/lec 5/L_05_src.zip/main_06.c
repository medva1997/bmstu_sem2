/*
����� 10
*/

#include <stdio.h>


void beep(void)
{
    printf("\a");
}


int main(void)
{
    beep;

    return 0;
}