#include <stdio.h>
#include "buy.h"

void goodbuy(void)
{
    printf("See you!\n");
}