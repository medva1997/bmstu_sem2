#ifndef __BUY__H__

#define __BUY__H__


void goodbuy(void);


#endif	// __BUY__H__