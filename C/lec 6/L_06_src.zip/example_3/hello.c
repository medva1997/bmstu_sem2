#include <stdio.h>
#include "hello.h"

// Test for make
void hello(void)
{
    printf("Hello, make!\n");
}