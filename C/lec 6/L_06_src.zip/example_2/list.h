// list.h

struct list_node
{
    void *data;
    struct list_node *next;
};


// ...